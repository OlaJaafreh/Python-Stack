from django.apps import AppConfig


class MovieActorCatConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'movie_actor_cat'
